create database hostel1;
use hostel1;

create table booking(booking_id varchar(50) primary key, date_of_booking  varchar (30),check_in_date  varchar (30), check_out_date
 varchar (30),room_id int,customer_id int,nights_stayed int,room_rate_per_night double, total_booking_value double);
drop table booking;
create table customer(customer_id int primary key,customer_name varchar(30),gender varchar(20),age int,
city varchar (20),loyalty_points int);

create table hostel(hostel_id int primary key,hostel_name varchar(30),location varchar(20),total_rooms int,
manager_name varchar(30),monthly_rent double);

create table room(room_id int primary key,room_type varchar(30),room_capacity int, room_rate double,
availability varchar(10), hostel_id int);
drop table room;
alter table booking
modify booking_id varchar(50);

select count(*)from room;
select *from room;
desc room;

select count(*)from hostel;
desc hostel;

select count(*)from customer;
desc customer;

select count(*)from booking;
select *from booking;
desc booking;


ALTER TABLE booking
add CONSTRAINT customer_room 
FOREIGN KEY (customer_id)
REFERENCES customer(customer_id);
SELECT customer_id FROM booking as s
WHERE customer_id NOT IN (SELECT customer_id FROM customer);
DELETE FROM booking
WHERE customer_id NOT IN (SELECT customer_id FROM customer);


ALTER TABLE booking
add CONSTRAINT c_room 
FOREIGN KEY (room_id)
REFERENCES room(room_id);
SELECT room_id FROM booking as s
WHERE room_id NOT IN (SELECT room_id FROM room);
DELETE FROM booking
WHERE room_id NOT IN (SELECT room_id FROM room);

ALTER TABLE room
ADD CONSTRAINT cid_room
FOREIGN KEY (hostel_id)
REFERENCES hostel(hostel_id);

